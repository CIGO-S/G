from google.cloud import storage
import os

def init_bucket(bucket_name):

  storage_client = storage.Client()
  bucket = storage_client.bucket(bucket_name)
  return bucket


def delete_folder(bucket_name, folder_name):
    bucket=init_bucket(bucket_name)
    blobs = bucket.list_blobs(prefix=f"{folder_name}/")
    for blob in blobs:
        blob.delete()

def upload_folder(bucket_name,folder_name):

  bucket=init_bucket(bucket_name)

  # Create a folder (or "directory") in the bucket
  blob = bucket.blob(f"{folder_name}/")
  blob.upload_from_string('')  # Empty string to represent a folder

  # Upload the entire content of the local folder
  for root, dirs, files in os.walk(folder_name):
      for file in files:
          local_file_path = os.path.join(root, file)
          destination_blob_name = f"{folder_name}/{os.path.relpath(local_file_path, folder_name)}"
          blob = bucket.blob(destination_blob_name)
          blob.upload_from_filename(local_file_path)

def download_folder(bucket_name,folder_path):


    # Create a client using Application Default Credentials (ADC)
    client = storage.Client()

    # Get the bucket and list objects in the specified folder
    bucket = client.bucket(bucket_name)
    path=f"./{folder_path}"
    blobs = bucket.list_blobs(prefix=f"{folder_path}/")
   
    
    if not os.path.exists(path):
        os.mkdir(path)
    # Download each object in the folder to the local directory

    for blob in blobs:
        if blob.name.split("/")[1]!="":
            # Create local file path
            local_file_path = blob.name
            # Download the object
  
            blob.download_to_filename(f"./{local_file_path}")



