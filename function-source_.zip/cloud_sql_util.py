import os
import asyncio
import asyncpg
from google.cloud.sql.connector import Connector
from pgvector.asyncpg import register_vector


async def init_connection():
  loop = asyncio.get_running_loop()
  async with Connector(loop=loop) as connector:
  # Create connection to Cloud SQL database
      conn: asyncpg.Connection = await connector.connect_async(
          os.getenv("INSTANCE_CONNECTION_NAME"),
          "asyncpg",
          user=os.getenv("DB_USER"),
          password=os.getenv("DB_PASS"),
          db=os.getenv("DB_NAME")
      )
  return conn

async def create_vectorial_db(conn,name):

  await conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
  await register_vector(conn)

  await conn.execute(
    f"""CREATE TABLE "{name}" (
          id BIGSERIAL PRIMARY KEY,
          content TEXT,
          embedding VECTOR(768))"""
  )

async def drop_table(conn,name):
  await conn.execute(
  f"""DROP TABLE IF EXISTS "{name}" """
  )


async def save(name,chunks):
  conn= await init_connection()
  await drop_table(conn,name)
  await create_vectorial_db(conn,name)
  rows = [(x["content"], x["embedding"]) for x in chunks]
  for row in rows:
    await conn.execute(
      f"""INSERT INTO "{name}" (content, embedding) VALUES ($1, $2)""",
      row[0],row[1]
    )

  await conn.close()




async def retrieve(name,query_embedding, similarity_threshold=0.7, num_matches=5):
  conn=await init_connection()

  # Use cosine similarity search to find documents
  results = await conn.fetch(f"""
      SELECT content
      FROM "{name}"
      WHERE 1 - (embedding <=> $1) > $2
      LIMIT $3                         
      """, 
      query_embedding, float(similarity_threshold), num_matches)
  await conn.close()

  return results