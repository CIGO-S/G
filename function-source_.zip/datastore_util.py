from google.cloud import ndb
from models import *


datastore_client = ndb.Client()

def store_messages(thread_id, messages=[]):
    """Stores a list of messages for the thread_id.

    Uses get_or_insert() to ensure only one Thread entity exists per thread_id.
    """

    if not thread_id:
        return

    with datastore_client.context():
        thread = Thread.get_or_insert(thread_id)
        thread.message_history = { "messages" : messages }
        thread.put()

def store_model_type(thread_id,model):
    """Stores a list of messages for the thread_id.

    Uses get_or_insert() to ensure only one Thread entity exists per thread_id.
    """

    if not thread_id:
        return

    with datastore_client.context():
        thread = Thread.get_or_insert(thread_id)
        thread.model_type = model
        thread.put()

def get_thread(thread_id):
    """Returns thread_obj for thread_id."""

    if not thread_id:
        return None

    with datastore_client.context():
        thread_obj = Thread.get_by_id(thread_id)
        return thread_obj

def delete_thread(thread_id):
    if not thread_id:
        return

    # key = ndb.Key('Thread', thread_id)
    # key.delete()

    with datastore_client.context():
        key = ndb.Key("Thread", thread_id)
        key.delete()

def store_configuracion(space_id, configuracion):

    if not space_id:
        return

    with datastore_client.context():
        configuracion_obj = Configuracion.get_or_insert(space_id)
        configuracion_obj.tipo_respuesta = configuracion["tipo_respuesta"]
        configuracion_obj.put()

def get_configuracion(space_id):
    
    if not space_id:
        return None

    with datastore_client.context():
        configuracion_obj = Configuracion.get_by_id(space_id)
        return configuracion_obj

def store_mensaje(datos_mensaje):

    if not datos_mensaje["correo"]:
        return

    with datastore_client.context():
        mensaje_obj = Mensaje.get_or_insert(datos_mensaje["id"])
        mensaje_obj.correo = datos_mensaje["correo"]
        mensaje_obj.pregunta = datos_mensaje["pregunta"]
        mensaje_obj.respuesta = datos_mensaje["respuesta"]
        mensaje_obj.put()

def store_soporte(datos_soporte):
    with datastore_client.context():
        reporte_obj = ReporteSoporte.get_or_insert(datos_soporte["id"])
        reporte_obj.correo = datos_soporte["correo"]
        reporte_obj.tipo_comentario = datos_soporte["tipo_comentario"]
        reporte_obj.comentario = datos_soporte["comentario"]
        reporte_obj.put()
    