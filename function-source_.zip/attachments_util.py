import io
import os
import asyncio
import pandas as pd

import auth_util
import datastore_util
import cloud_sql_util
import cloud_storage_util

from googleapiclient.http import MediaIoBaseDownload
from langchain.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores.faiss import FAISS
from langchain.embeddings import VertexAIEmbeddings
from langchain.document_loaders import Docx2txtLoader
from PIL import Image 
import logging
import shutil



attachment_bucket=os.environ.get("ATTACHMENTS_BUCKET")
embeddings=VertexAIEmbeddings()

def get_attachment(attachment):
  
    resourceName=attachment[0].get('attachmentDataRef',{}).get('resourceName',"")
    attachment_name=attachment[0].get('contentName','')

    chat_service = auth_util.google_chat_service()
    request = chat_service.media().download_media(resourceName=resourceName)

    fileInfo = io.BytesIO()
    downloader = MediaIoBaseDownload(fileInfo, request)
    done = False
    while done is False:
        status, done = downloader.next_chunk()
        
    with io.open(attachment_name,"wb") as f:
        fileInfo.seek(0)
        f.write(fileInfo.read())
      
    return attachment_name


def process_attachments(attachment,thread_id,method):
  attachment_type=attachment[0].get('contentType','')
  file_info=get_attachment(attachment)
  delete_user_folder(thread_id)
  

  if ("pdf" in attachment_type) | ("word" in attachment_type):
    if "pdf" in attachment_type:
      loader = PyPDFLoader(file_info)

    elif "word" in attachment_type:
      loader=Docx2txtLoader(file_info)
    
    documents = loader.load()

    if method=="FAISS":
      upload_db(documents,thread_id)
    elif method=="SQL":
      save_data_sql(thread_id,documents)

    datastore_util.store_model_type(thread_id, "ATTACHMENTS")

  elif "csv" in attachment_type:
    data=pd.read_csv(file_info, on_bad_lines='skip')
    if len(data.columns)<=1:
      data=pd.read_csv(file_info, on_bad_lines='skip',sep=";")
    upload_tabular_data(data,thread_id)
    datastore_util.store_model_type(thread_id, "TABULAR")

  elif "sheet" in attachment_type:
    data=pd.read_excel(file_info)
    upload_tabular_data(data,thread_id)
    datastore_util.store_model_type(thread_id, "TABULAR")

  elif "image" in attachment_type:
    data=Image.open(file_info)
    if "png" in attachment_type:
      data=data.convert('RGB')
    upload_image(data,thread_id)
    datastore_util.store_model_type(thread_id, "IMAGE")



  else:
    return {"text":"No puedo procesar el archivo ingresado"}

  os.remove(file_info)
  delete_user_folder(thread_id)
  return{"text":"Archivo procesado correctamente, ahora las preguntas que me hagas las responderé con respecto a este, si ya no quieres tener en cuenta este archivo puedes escribir el comando /BorrarMemoria "}

def documents_chunks(documents):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=700, chunk_overlap=50,separators=["\n","\n\n"])
    chunks = text_splitter.split_documents(documents)
    return chunks

def vectorstore_faiss(documents,embeddings,folder_name):
    vectorstore_contents = FAISS.from_documents(documents, embeddings)
    vectorstore_contents.save_local(folder_name)
    cloud_storage_util.delete_folder(attachment_bucket,folder_name)
    cloud_storage_util.upload_folder(attachment_bucket,folder_name)

def upload_db(documents,folder_name):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=700, chunk_overlap=100,separators=["\n","\n\n"])
    docs = text_splitter.split_documents(documents)
    vectorstore_contents = FAISS.from_documents(docs, embeddings)
    vectorstore_contents.save_local(folder_name)
    cloud_storage_util.delete_folder(attachment_bucket,folder_name)
    cloud_storage_util.upload_folder(attachment_bucket,folder_name)

def get_retriever(folder_name):
  cloud_storage_util.download_folder("attachments-guia",folder_name)
  vector_database = FAISS.load_local(folder_name,embeddings)
  retriever = vector_database.as_retriever(search_type="similarity", search_kwargs={"k": 4})
  return retriever
  
def get_docs(folder_name):
  cloud_storage_util.download_folder("attachments-guia",folder_name)
  vector_database = FAISS.load_local(folder_name, embeddings)
  docs=[]
  index=vector_database.index_to_docstore_id
  for i in range(len(index)):
    docs.append(vector_database.docstore._dict[index[i]])
  return docs
#Vector databse in Cloud Sql(Postgres) with PGvector 
def embed(chunks, batch_size = 3):
  for i in range(0, len(chunks), batch_size):
    request = [x["content"] for x in chunks[i : i + batch_size]]
    response = embeddings.embed_documents(request)

    for x, e in zip(chunks[i : i + batch_size], response):
      x["embedding"] = e

def chunk(document):
  text_splitter = RecursiveCharacterTextSplitter(
    separators=[".", "\n"],
    chunk_size=1024,
    chunk_overlap=0,
    length_function=len,
  )

  splits = text_splitter.create_documents([document])
  chunks = [{"content": s.page_content} for s in splits]
  return chunks


def save_data_sql(name,documents):
  text = ""
  for page in documents:
      text += page.page_content + "\n"
  chunks = chunk(text)
  embed(chunks)
  asyncio.run(cloud_sql_util.save(name,chunks))


def sql_get_matches(name,user_query):
    query_embedding= embeddings.embed_query(user_query)
    matches = asyncio.run(cloud_sql_util.retrieve(name,str(query_embedding)))
    matches_str=[]
    for values in matches:
      values_str = map(str, values.values())
      record_str = ''.join(values_str)
      matches_str.append(record_str)
    return matches_str

def upload_tabular_data(data,folder_name):
  os.mkdir(f"./{folder_name}")
  data.to_csv(f"./{folder_name}/{folder_name}.csv",index=False,sep=',')
  cloud_storage_util.delete_folder(attachment_bucket,folder_name)
  cloud_storage_util.upload_folder(attachment_bucket,folder_name)

def get_tabular_data(folder_name):
  cloud_storage_util.download_folder(attachment_bucket,folder_name)
  data=pd.read_csv(f"./{folder_name}/{folder_name}.csv")
  return data

def upload_image(data,folder_name):

  os.mkdir(f"./{folder_name}")
  data.save(f"./{folder_name}/{folder_name}.jpg")
  cloud_storage_util.delete_folder(attachment_bucket,folder_name)
  cloud_storage_util.upload_folder(attachment_bucket,folder_name)

def delete_user_folder(folder_name):
  path=f"./{folder_name}"
  logging.warning(os.listdir(r"./"))
  if os.path.exists(path):
    try:
      shutil.rmtree(path)
    except:
      os.rmdir(path)

