from google.cloud import ndb

class Thread(ndb.Model):
    message_history = ndb.JsonProperty()
    timestamp = ndb.DateTimeProperty(auto_now_add = True)
    model_type=ndb.StringProperty()

    def get_messages(self):
        return self.message_history['messages']
    def get_model_type(self):
        return self.model_type

class Configuracion(ndb.Model):
    tipo_respuesta = ndb.StringProperty()


class Mensaje(ndb.Model):
    correo = ndb.StringProperty()
    fecha_hora = ndb.DateTimeProperty(auto_now_add = True)
    pregunta = ndb.TextProperty()
    respuesta = ndb.TextProperty()

class ReporteSoporte(ndb.Model):
    correo = ndb.StringProperty()
    fecha_hora = ndb.DateTimeProperty(auto_now_add = True)
    tipo_comentario = ndb.StringProperty()
    comentario = ndb.StringProperty()


