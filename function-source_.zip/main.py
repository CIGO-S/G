import os
import flask
import functions_framework
import logging
import google.cloud.logging
import time
import openai
import gpt_util
import gemini_util
import datastore_util
import attachments_util
from auth_util import is_request_valid
from openai import OpenAIError
import time

logging_client = google.cloud.logging.Client()
logging_client.setup_logging(log_level=logging.INFO)
# FAISS SQL LLAMAINDEX
METODO="FAISS"
@functions_framework.http
def respondChat(request):
    
    if not is_request_valid(request):
      return {"text":"Unauthorized request"}
    """Handles incoming messages from Google Chat."""
    event_data = request.get_json()
    event_type = event_data['type']
    space_name = event_data['space']['name'].split("/")[1]


    # Bot added
    if event_type == 'ADDED_TO_SPACE':
        
        # Added to a room
        if event_data['space']['type'] == 'ROOM':
            return { "text" : f"¡Hola! Soy el asistente virtual de Davivienda impulsado por ChatGPT y CIGO.\nDesde acá puedo responder preguntas y ayudarlos con dudas que tengan en la sala. Recuerden etiquetarme cuando me pregunten algo. Empecemos!🤖🚀\n\nEn cualquier momento pueden escribir `/ayuda` si quieren conocer información adicional."}

        # Added to a DM
        elif event_data['space']['type'] == 'DM':
            user_display_name = event_data['user']['displayName']
            return { "text" : f"¡Hola {user_display_name}!\nSoy el asistente virtual de Davivienda impulsado por ChatGPT y CIGO.\nDesde acá puedo responder preguntas y ayudarte con dudas que tengas. Empecemos!🤖🚀\n\nEn cualquier momento puedes escribir `/ayuda` si quieres conocer información adicional."}

    # Bot removed
    elif event_type == 'REMOVED_FROM_SPACE':
        return {}

    # A normal message event
    elif event_type == 'MESSAGE':
        return process_message_event(event_data)
    # Card button is clicked
    elif event_type == "CARD_CLICKED":
        return process_card_clicked(event_data,space_name)



def process_message_event(event_data):
  
    incoming_message = event_data.get('message', {})
    """Processes message event."""

    user_text = incoming_message.get('argumentText', "")
    attachment=incoming_message.get("attachment","")
    user_name = event_data['user']['name']
    user_email = event_data['user']['email']
    user_id = user_name.split("/")[1]
    space_name = event_data['space']['name'].split("/")[1]
    space_type = event_data['space']['spaceType']



    # if this is a direct message to the bot, create our own thread_id
    # so we can store the history of messages
    thread_id = None
    if space_type == "DIRECT_MESSAGE":
        # thread_id = "%s-%s" % (user_id, space_name)
        thread_id = space_name

    if "slashCommand" in incoming_message:
      commandId = incoming_message["slashCommand"]["commandId"]
      if commandId == "1": return open_configuration_dialog(event_data)
      if commandId == "2": return remove_chat_history(thread_id)
      if commandId == "3": return get_help_text()
      if commandId == "4": return open_support_dialog(event_data)

 

    # get previous messages to continue conversation
    thread_obj = datastore_util.get_thread(thread_id)
    if attachment =="":
      if not thread_obj:
        datastore_util.store_model_type(thread_id, "TEXT")
        thread_obj = datastore_util.get_thread(thread_id)
    else:
      datastore_util.delete_thread(thread_id)
      try:
        return attachments_util.process_attachments(attachment,thread_id,METODO)
      except Exception as e:
        return {"text":"Error en el archivo, porfavor revisa el contenido del archivo y vuelve a intentarlo, Error : "+str(e)}

    
    model=thread_obj.get_model_type()
    if model == "ATTACHMENTS":
      model_response=gpt_util.attachments_response(thread_id,user_text,METODO)
      
      return respuesta(space_name,model_response)
    elif model =="TABULAR":

      model_response=gpt_util.QA_Tabular(thread_id,user_text)
      return respuesta(space_name,model_response)

    elif model =="IMAGE":

      model_response=gemini_util.reponse_gemini_vison(thread_id,user_text)
      return respuesta(space_name,model_response)
      
     
    # logging.info("user_text %s" % user_text)
    # logging.info("thread_id: %s" % thread_id)
    # logging.info("user_text %s" % user_text)

    messages = []
    try:
      history_messages = thread_obj.get_messages()
    except:
      history_messages=False

    if history_messages:
        messages = thread_obj.get_messages()


    else:
        # set guidance for ChatGPT
        guidance = "Eres un asistente que va a ayudar a resolver preguntas a cualquier tipo de persona dentro de una organizacion. Si te preguntan si aceptas archivos adjuntos diles que sí, que solo deben adjuntar el archivo y poder hacerle preguntas sobre el mismo.Si te hacen una pregunta sobre la cual no tienes conocimiento responde que no tienes la información y que se debe consultar en otra fuente."
        messages.append({"role": "system", "content" : guidance})
        
    
    # add new message to list
    messages_gemini=messages.copy()
    messages.append( {"role": "user", "content": user_text} )
    total_tokens = gpt_util.get_token_count(messages)
    logging.warning(str(total_tokens))
    logging.warning(str(messages[1]))
    while total_tokens > 3500 and len(messages) >= 2:
      if messages[1].get("role","")=="user":
        del messages[1]
        del messages[1]
      else:
        del messages[1]
      total_tokens = gpt_util.get_token_count(messages)

    if os.environ.get("LLM_MODEL")=="GPT":
      # get new gpt response
      try:
          gpt_response = gpt_util.get_gpt_response(messages)
      except OpenAIError as e:
          return { "text" : str(e)}

      

      
    elif os.environ.get("LLM_MODEL")=="GEMINI":
      gpt_response={}
      gpt_response["gpt_response"] = gemini_util.gemini_responce(messages_gemini,user_text)


    messages.append( {"role": "assistant", "content": gpt_response["gpt_response"]} )
    datastore_util.store_messages(thread_id, messages)
    
    datos_mensaje = {
        "id": str(int(time.time_ns())),
        "correo":  user_email,
        "pregunta": user_text,
        "respuesta": gpt_response["gpt_response"] 
    }
    datastore_util.store_mensaje(datos_mensaje)
    return respuesta(space_name,gpt_response["gpt_response"])


def respuesta(space_name,model_response):
  tipo_respuesta = "TEXTO"
  configuracion = datastore_util.get_configuracion(space_name)
  if configuracion is not None:
      tipo_respuesta =  configuracion.tipo_respuesta.upper()

  if tipo_respuesta == "CARTA":
    chat_response = create_card_response(model_response)
  else:
      chat_response = { 
          "text" : model_response
      }
  return chat_response


def create_card_response(gpt_response):
    return {
        "cardsV2": [
        {
            "cardId": str(int(time.time_ns())),
            "card": {
            "header": {
                "title": "GuIA",
                "imageUrl":"https://i.ibb.co/smSDC7K/Logo-Dav-Negro.png",
                "imageType": "CIRCLE",
                "imageAltText": "Avatar DaviChat",
            },
            "sections":[
                {
                "collapsible": True,
                "uncollapsibleWidgetsCount": 1,
                "header": "Respuesta",
                "widgets": [
                    {
                    "textParagraph": {
                        "text": gpt_response
                    }
                    }
                ]
                
                }
            ]
            }
        }
        ]
    }

def open_configuration_dialog(event_data):
    return {
    "action_response": {
      "type": "DIALOG",
      "dialog_action": {
        "dialog": {
          "body": {
            "sections": [
              {
                "header": "Configuración Asistente",
                "widgets": [
                    {
                        "textParagraph": {
                            "text": "Puedes personalizar la forma en que se muestran tus respuestas<br><br><b>Texto: </b>Usa esta opción si quieres ver tu respuesta como un texto amplio. Es útil cuando tu respuesta contiene tablas, listas o código<br><b>Carta: </b>Usa esta opción para ver tu respuesta de manera compacta. Es útil si tu respuesta es únicamente texto"
                            
                        }
                    },
                    {
                        "selectionInput": {
                        "type": "RADIO_BUTTON",
                        "label": "Selecciona una forma de respuesta",
                        "name": "tipoRespuesta",
                        "items": [
                            {
                            "text": "Texto",
                            "value": "Texto",
                            "selected": False
                            },
                            {
                            "text": "Carta",
                            "value": "Carta",
                            "selected": False
                            }
                        ]
                        }
                    }
                ]
              }
            ],
            "fixed_footer": {
              "primaryButton": {
                "text": "Guardar",
                "onClick": {
                  "action": {
                    "function": "guardarConfiguracion"
                  }
                }
              },
              "secondaryButton": {
                "text": "Cancelar",
                "onClick": {
                  "action": {
                    "function": "cancelar"
                  }
                }
              }
            }
          }
        }
      }
    }
  }

def open_support_dialog(event_data):
    return {
    "action_response": {
      "type": "DIALOG",
      "dialog_action": {
        "dialog": {
          "body": {
            "sections": [
              {
                "header": "Soporte Chat GuIA",
                "widgets": [
                    {
                        "textParagraph": {
                            "text": "A través de este canal puedes reportar el problema que tuviste con el chat. También puedes dejar un comentario si tienes una idea de mejora o hay algo en lo que crees que debemos mejorar 🧑‍💻"
                        }
                    },
                    {
                        "selectionInput": {
                            "type": "RADIO_BUTTON",
                            "label": "Tipo",
                            "name": "tipo_comentario",
                            "items": [
                            {
                                "text": "Reporte de error",
                                "value": "Reporte de error",
                                "selected": False
                            },
                            {
                                "text": "Comentario de mejora",
                                "value": "Comentario de mejora",
                                "selected": False
                            }
                            ]
                        }
                    },
                    {
                        "textInput": {
                            "label": "Comentario",
                            "type": "MULTIPLE_LINE",
                            "name": "comentario"
                        }
                    }
                ]
              }
            ],
            "fixed_footer": {
              "primaryButton": {
                "text": "Guardar",
                "onClick": {
                  "action": {
                    "function": "guardarReporteSoporte"
                  }
                }
              },
              "secondaryButton": {
                "text": "Cancelar",
                "onClick": {
                  "action": {
                    "function": "cancelar"
                  }
                }
              }
            }
          }
        }
      }
    }
  }

def process_card_clicked(event_data,thread_id):
    invoked_function = event_data["common"]["invokedFunction"]
    correcto = True
    
    if invoked_function == "guardarConfiguracion":
        save_configuration(event_data)
        message = "Configuración guardada"

    elif invoked_function == "guardarReporteSoporte":
        correcto = validarCampos(event_data)
        if correcto:
            save_support_report(event_data)
            message = "Reporte enviado"
        else: message = "Completa todos los campos"
            
    elif invoked_function == "cancelar": message = "Acción cancelada"

    elif invoked_function == "delete_context":
      datastore_util.store_model_type(thread_id,"TEXT")
      message = "Contexto borrado del archivo adjunto"

      return {
       "cardsV2": [
        {
            "cardId": str(int(time.time_ns())),
            "card": {
            "sections":[
                {
                "collapsible": True,
                "uncollapsibleWidgetsCount": 1,
                "widgets": [
                    {
                    "textParagraph": {
                        "text": message
                    }
                    }
                ]
                
                }
            ]
            }
        }
        ]
    }

      

    
    return {
        "actionResponse": {
            "type": "DIALOG",
            "dialogAction": {
                "actionStatus": {
                    "statusCode": "OK",
                    "userFacingMessage": message
                }
            }
        }
    }
    

    
def save_configuration(event_data):

    space_id = event_data["space"]["name"].split("/")[1]
    configuracion = {
        "tipo_respuesta": event_data["common"]["formInputs"]["tipoRespuesta"]["stringInputs"]["value"][0],
    }
    datastore_util.store_configuracion(space_id, configuracion)


def validarCampos(event_data):
    tipo_comentario = event_data["common"]["formInputs"]["tipo_comentario"]["stringInputs"]["value"][0]
    comentario = event_data["common"]["formInputs"]["comentario"]["stringInputs"]["value"][0]

    if not tipo_comentario or not comentario : return False
    return True

def save_support_report(event_data):
    datos_soporte = {
        "id": str(int(time.time_ns())),
        "correo": event_data["user"]["email"],
        "tipo_comentario":  event_data["common"]["formInputs"]["tipo_comentario"]["stringInputs"]["value"][0],
        "comentario":  event_data["common"]["formInputs"]["comentario"]["stringInputs"]["value"][0],
    }

    datastore_util.store_soporte(datos_soporte)
    
    
def remove_chat_history(thread_id):
    datastore_util.delete_thread(thread_id)
    datastore_util.store_model_type(thread_id, "TEXT")

    return {
        "text": "La memoria de la conversación se ha borrado"
    }


def handle_image_command(image_prompt):
    try:
      image_url = gpt_util.create_image_with_prompt(image_prompt)
    except:
      return{
        "text": "Error al generar la imagen"
      }


    cards = {
      "cardsV2": [
        {
          "cardId": str(int(time.time_ns())),
          "card": {
            "sections": [
              {
                "header": "Imagen Generada por DALL-E",
                "widgets": [
                  {
                    "image": {
                      "imageUrl": image_url,
                      "onClick": {
                        "openLink": {
                          "url": image_url
                        }
                      },
                    }
                  }
                ]
              }
            ]
          }
        }
      ]
    }

    return cards
def get_help_text():
    return {
        "text": f"¡Hola! Soy el asistente virtual de Davivienda impulsado por ChatGPT y CIGO. "\
        "Desde acá puedo responder preguntas y ayudarte con dudas que tengas 🤖🚀\n\n"\
        "Escribe la consulta o pregunta que quieres realizar y te daré la respuesta. Ten en cuenta los siguientes tips:\n"\
        "-Recuerda ser claro y específico en tu pregunta.\n"\
        "-Para obtener mejores resultados proporciona un contexto relevante como antecedentes o detalles adicionales\n"\
        "-Utiliza un lenguaje sencillo para que la conversación sea efectva y facil de entender\n"\
        "\n"\
        "Estas son algunas funciones adicionales que tengo disponibles:\n"\
        "Escribe `/configuracion` para personalizar la forma en la que te muestro las respuestas\n"\
        "Escribe `/borrarMemoria` para borrar la memoria de la conversación. Es útil cuando quires cambiar el tema de la conversación."
    }
    
       
    