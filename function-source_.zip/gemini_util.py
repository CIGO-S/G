import google.generativeai as genai
import vertexai
from vertexai.generative_models import GenerativeModel, Part,Content
import os
import copy
import logging

model=GenerativeModel("gemini-1.0-pro")
multimodal_model = GenerativeModel("gemini-1.0-pro-vision")
attachment_bucket=os.environ.get("ATTACHMENTS_BUCKET")
def insert(list1, var, i):
    new_list = list1[:i]
    new_list.append(var)
    new_list.extend(list1[i:])
    return new_list

def openai_to_gemini_request(messages):
  message_openai = copy.deepcopy(messages)
  dictionary={"system":"user","assistant":"model","user":"user"}
  history=[]
  for message in message_openai:
    history.append(Content(role=dictionary.get(message["role"],""),parts=[Part.from_text(message["content"])]))

  history=insert(history,Content(role="model",parts=[Part.from_text("ok")]),1)
  return history

  


def gemini_responce(history_messages,message):
  config = {
    "temperature": 0.5,
    "top_p": 0.85
  }
  history=openai_to_gemini_request(history_messages)
  logging.warning("Chat history"+str(history))
  chat=model.start_chat(history=history)
  response = chat.send_message(message,generation_config=config)
  return response.text



def reponse_gemini_vison(folder_name,user_text):
  # Query the model
  response = multimodal_model.generate_content(
      [
          # Add an example image
          Part.from_uri(
              f"gs://{attachment_bucket}/{folder_name}/{folder_name}.jpg", mime_type="image/jpeg"
          ),
          # Add an example query
          user_text,
      ]
  )
  return response.text