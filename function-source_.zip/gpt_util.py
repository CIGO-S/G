#Note: The openai-python library support for Azure OpenAI is in preview.
import os
import openai
import attachments_util
import tiktoken
import logging
import asyncio
from openai import AzureOpenAI
from langchain.chat_models import AzureChatOpenAI
from langchain.chains import ConversationalRetrievalChain
from langchain.chains.qa_with_sources import load_qa_with_sources_chain
from langchain.docstore.document import Document
from langchain.prompts import PromptTemplate
from langchain.agents import AgentType
from langchain_experimental.agents.agent_toolkits import create_pandas_dataframe_agent
from langchain.chains.summarize import load_summarize_chain

from langchain.chains import MapReduceDocumentsChain
from langchain.chains import ReduceDocumentsChain
from langchain.chains.combine_documents.stuff import StuffDocumentsChain
from langchain.chains import LLMChain

llm=AzureChatOpenAI(openai_api_key=os.getenv("OPENAI_API_KEY"), deployment_name="Test", model_name="gpt-3.5-turbo")
client=AzureOpenAI(
  api_key = os.getenv("OPENAI_API_KEY"),  
  api_version = os.getenv("OPENAI_API_VERSION"),
  azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
)
def get_openia_info():
    client=AzureOpenAI(
      api_key = os.getenv("OPENAI_API_KEY"),  
      api_version = os.getenv("OPENAI_API_VERSION"),
      azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    )

    return client
def get_gpt_response(messages):
    client=get_openia_info()

    response = client.chat.completions.create(
        model = "Test", # engine = "deployment_name".
        messages = messages,
        temperature = 0.5,
        top_p = 0.85
    )

    # print(response)
    # print(response['choices'][0]['message']['content'])

    total_tokens = response.usage.total_tokens
    gpt_response = response.choices[0].message.content

    return {
        "gpt_response": gpt_response,
        "total_tokens": total_tokens
    }

def llm_retriever(space_name,question,chat_history=""):
  retriever=attachments_util.get_retriever(space_name)
  
  qa = ConversationalRetrievalChain.from_llm(
    llm=llm, 
    chain_type="stuff", 
    retriever=retriever, 
    return_source_documents=True,
    return_generated_question=True,
    )
  result = qa({"question": question,"chat_history":chat_history})
  return result["answer"]
def qa(matches, question):
    
    metadata = {"source": "text"}
    documents = [Document(page_content=text,metadata=metadata) for text in matches]

    template="""Responde a la pregunta con respecto al siguiente contexto
    =========
    {summaries}
    =========
    Respuesta Final:"""
    variables=["summaries", "name"]
    prompt_template = PromptTemplate(
        template=template,
        input_variables=variables,
    )
    chain = load_qa_with_sources_chain(
        llm=llm,
        prompt=prompt_template,
        verbose=False,
    )
    answer = chain.run(input_documents=documents, question=question)
    return answer

def sql_retriever(space_name,question,chat_history=""):
  matches=attachments_util.sql_get_matches(space_name,question)
  response = qa(matches,question)
  return response

def attachments_response(thread_id,user_text,method):
  election=summarization_election(user_text)
  if "1" in election:
    return summarize_retriever_2(thread_id,user_text)
  if method=="FAISS":
    return llm_retriever(thread_id,user_text)

  elif method=="SQL":
    return sql_retriever(thread_id,user_text)

def QA_Tabular(thread_id,user_text):

  data=attachments_util.get_tabular_data(thread_id)
  agent = create_pandas_dataframe_agent(llm, data,agent_type=AgentType.OPENAI_FUNCTIONS)
  try:
    response=agent.run(user_text)
  except:
    respnse="No puedo responser a tu pregunta, porfavor intenta nuevamente."
  return response

def get_token_count(messages):
  encoding = tiktoken.encoding_for_model("gpt-3.5-turbo")

  count = 0
  for message in messages:
    count += len(encoding.encode(message["content"]))
  return count

def get_token_from_docs(docs):
  text=""
  for doc in docs:
    text+=doc.page_content
  encoding = tiktoken.encoding_for_model("gpt-3.5-turbo")
  num_tokens=len(encoding.encode(text))
  return num_tokens


def summarization_election(user_text):
  guidance = "Eres un asistente que ayuda a elegir entre dos modelos de inteligencia artificial, debes retornar '1' si el usuario te pide hacer un resumen , de lo contrario retorna '0', tu unicamente debe ser '1' o '0'."
  messages=[{"role": "system", "content" : guidance},{"role":"user","content":user_text}]
  client=get_openia_info()
  response = client.chat.completions.create(
      model = "Test",
      messages = messages,
      temperature = 0,
  )
  election = response.choices[0].message.content
  return election



def summarize_retriever(thread_id,user_text):
  
  docs=attachments_util.get_docs(thread_id)
  num_tokens=get_token_from_docs(docs)
  if num_tokens>4900:
    return "Lo siento no puedo resumir este archivo debido a que es muy extenso, por otro lado puedes preguntarme cosas del contenido del texto"


  prompt=""" Escribe un resumen muy breve de lo siguiente: 
  "{text}"

  """+user_text+":"
  prompt_template=PromptTemplate(template=prompt,input_variables=["text"])
  summary_chain=load_summarize_chain(llm=llm,chain_type='map_reduce',map_prompt=prompt_template,combine_prompt=prompt_template)
  output=summary_chain.run(docs)
  return output

def summarize_retriever_2(thread_id,user_text):
  docs=attachments_util.get_docs(thread_id)
  num_tokens=get_token_from_docs(docs)
  if num_tokens>4900:
    return "Lo siento no puedo resumir este archivo debido a que es muy extenso, por otro lado puedes preguntarme cosas del contenido del texto"
  logging.warning("tokens: "+str(num_tokens))
  context=""
  client=get_openia_info()

  for doc in docs:
    initial_prompt=doc.page_content+ " resume el siguiente de una manera muy corta conservando lo más importante, si no es relevante no retornes nada:"
    prompt=[{"role":"system","content":"Eres un asistente experto en resumir texto resume el siguiente texto en muy pocas palabras"},{"role":"user","content":initial_prompt}]
    response=client.chat.completions.create(model="Test",messages=prompt,temperature=0.1)
    context+=response.choices[0].message.content+"/n"

  final_prompt=[{"role":"system","content":"Eres un asistente experto en resumir texto separado por /n si el fragmento dice que no es relevante ignoralo, resumelo en un texto obteniendo los más importante"},{"role":"user","content":context+" "+user_text}]
  final_response=client.chat.completions.create(model="Test",messages=final_prompt,temperature=0.7)
  summarize=final_response.choices[0].message.content

  return summarize



async def generate_initial_response(text):
  initial_prompt=text+ " resume el siguiente texto de una manera concisa, si no es relevante no retornes nada:"
  prompt=[{"role":"system","content":"Eres un asistente experto en resumir texto resume el siguiente texto en pocas palabras"},{"role":"user","content":initial_prompt}]
  response=client.chat.completions.create(model="Test",messages=prompt,temperature=0.1)
  return response.choices[0].message.content+"/n"

async def process_responces(docs):
  context=""
  tasks=[generate_initial_response(doc.page_content+ " resume el siguiente texto de una manera concisa, si no es relevante no retornes nada:") for doc in docs]

  for task in asyncio.as_completed(tasks):
    response=await task
    context+=response+"/n"
    return context

def summarize_retriever_3(thread_id,user_text):
  docs=attachments_util.get_docs(thread_id)
  num_tokens=get_token_from_docs(docs)
  context=""
  client=get_openia_info()
  context=asyncio.run(process_responces(docs))
  final_prompt=[{"role":"system","content":"Eres un asistente experto en resumir texto separado por /n identifica las ideas principales de cada fragmento y resumelo"},{"role":"user","content":context+" "+user_text}]
  final_response=client.chat.completions.create(model="Test",messages=final_prompt,temperature=0.7)
  summarize=final_response.choices[0].message.content
  return summarize